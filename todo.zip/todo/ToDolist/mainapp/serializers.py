from rest_framework import serializers
from .models import *

class ToDoSerializer(serializers.ModelSerializer):
    model=ToDo
    fields=('id','title','description','date','completed')